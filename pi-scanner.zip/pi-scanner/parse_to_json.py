#!/usr/bin/env python3
import json
import xml.etree.ElementTree as ET
import sys
import os

if len(sys.argv) < 3:
    print("Uso: parse_to_json.py <input_xml> <output_json>")
    sys.exit(1)

INPUT = sys.argv[1]
OUTPUT = sys.argv[2]

hosts = []

try:
    tree = ET.parse(INPUT)
    root = tree.getroot()
except ET.ParseError as e:
    print(f"[!] XML inválido ({INPUT}): {e}. Generando JSON vacío.")
else:
    for host in root.findall("host"):
        addr = host.find("address")
        if addr is None:
            continue

        ip = addr.get("addr")

        ports_list = []
        ports = host.find("ports")
        if ports is not None:
            for p in ports.findall("port"):
                state_el = p.find("state")
                if state_el is None or state_el.get("state") != "open":
                    continue

                service = p.find("service")
                ports_list.append({
                    "port": p.get("portid"),
                    "protocol": p.get("protocol"),
                    "service": service.get("name") if service is not None else "",
                    "version": service.get("version") if service is not None else ""
                })

        hosts.append({
            "ip": ip,
            "ports": ports_list
        })

data = {"hosts": hosts}

os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)

with open(OUTPUT, "w") as f:
    json.dump(data, f, indent=2)

print(f"[OK] Guardado: {OUTPUT}")
