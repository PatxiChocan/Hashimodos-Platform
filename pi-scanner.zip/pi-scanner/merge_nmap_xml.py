#!/usr/bin/env python3
import os
import xml.etree.ElementTree as ET

BASE_RESULTS = "/opt/pi-scanner/results"

def get_latest_results_dir(base_path):
    subdirs = [
        os.path.join(base_path, d)
        for d in os.listdir(base_path)
        if os.path.isdir(os.path.join(base_path, d))
    ]
    if not subdirs:
        raise RuntimeError(f"No hay directorios de resultados en {base_path}")
    return max(subdirs, key=os.path.getmtime)

def merge_nmap_xml(directory):
    root_merged = None

    for filename in sorted(os.listdir(directory)):
        if not filename.lower().endswith(".xml"):
            continue

        filepath = os.path.join(directory, filename)
        print(f"[*] Procesando {filepath}")

        try:
            tree = ET.parse(filepath)
        except ET.ParseError as e:
            print(f"[!] No se puede parsear {filepath}: {e}. Se ignora.")
            continue

        if root_merged is None:
            root_merged = tree.getroot()
        else:
            root = tree.getroot()
            for host in root.findall("host"):
                root_merged.append(host)

    if root_merged is None:
        print("[!] Ningún XML válido encontrado. Creando nmaprun vacío.")
        root_merged = ET.Element("nmaprun")

    return ET.ElementTree(root_merged)

if __name__ == "__main__":
    latest_dir = get_latest_results_dir(BASE_RESULTS)
    print(f"[+] Carpeta detectada: {latest_dir}")

    merged = merge_nmap_xml(latest_dir)
    output_file = os.path.join(latest_dir, "merged_nmap.xml")
    merged.write(output_file, encoding="utf-8", xml_declaration=True)
    print(f"[+] Fichero final: {output_file}")
