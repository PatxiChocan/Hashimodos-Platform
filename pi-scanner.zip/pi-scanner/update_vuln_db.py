#!/usr/bin/env python3
import requests
import json
from datetime import datetime

# Ruta de salida de la base de datos
OUTPUT = "/opt/pi-scanner/vuln_db.json"

# URL KEV (CISA)
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

# URL NVD API
NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# Limite máximo de vulnerabilidades por top
TOP_LIMIT = 150

def fetch_kev():
    print("[*] Descargando KEV CISA...")
    try:
        r = requests.get(KEV_URL, timeout=10)
        data = r.json()
        kev_list = data.get("vulnerabilities", [])
        print(f"[+] KEV cargadas: {len(kev_list)}")
        return kev_list
    except Exception as e:
        print(f"[ERROR] No se pudo descargar KEV: {e}")
        return []

def fetch_critical_cves(service_name):
    """Busca CVEs críticos de un servicio en NVD"""
    q = service_name.lower().strip()
    url = f"{NVD_URL}?keywordSearch={q}&limit=50"
    try:
        r = requests.get(url, timeout=5)
        data = r.json()
    except:
        return []

    cves = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        metrics = cve.get("metrics", {})

        cvss = None
        severity = None
        if "cvssMetricV31" in metrics:
            cvss_data = metrics["cvssMetricV31"][0]["cvssData"]
            cvss = cvss_data.get("baseScore", 0.0)
            severity = cvss_data.get("baseSeverity", "UNKNOWN")
        elif "cvssMetricV2" in metrics:
            cvss_data = metrics["cvssMetricV2"][0]["cvssData"]
            cvss = cvss_data.get("baseScore", 0.0)
            severity = cvss_data.get("baseSeverity", "UNKNOWN")

        cves.append({
            "cve": cve.get("id"),
            "description": cve.get("descriptions", [{}])[0].get("value"),
            "cvss": cvss,
            "severity": severity.lower() if severity else "unknown",
            "published": cve.get("published"),
            "updated": cve.get("lastModified"),
            "source": "NVD"
        })

    return cves

if __name__ == "__main__":
    database = {}

    # 1) KEV
    kev_list = fetch_kev()
    for v in kev_list:
        cve_id = v.get("cveID")
        database[cve_id] = {
            "cve": cve_id,
            "description": v.get("vulnerabilityName"),
            "cvss": 10.0,
            "severity": "critical",
            "published": v.get("dateAdded"),
            "updated": v.get("dateAdded"),
            "source": "KEV"
        }

    # Guardar JSON inicial
    sorted_db = dict(list(database.items())[:TOP_LIMIT])
    with open(OUTPUT, "w") as f:
        json.dump(sorted_db, f, indent=2)
    print(f"[OK] Base de datos generada: {OUTPUT}")
