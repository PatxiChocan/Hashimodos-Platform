#!/usr/bin/env python3
from flask import Flask, jsonify, send_file, request
import requests
import subprocess
import os
import threading
import time
import json

app = Flask(__name__)

BASE_PATH = "/opt/pi-scanner"
JSON_FILE = os.path.join(BASE_PATH, "scan_final.json")
SCRIPT_FILE = os.path.join(BASE_PATH, "scan_run.sh")
STATUS_FILE = os.path.join(BASE_PATH, "scan_status.txt")
PARAMS_FILE = os.path.join(BASE_PATH, "scan_params.json")

# Estado global del escaneo
scan_running = False
last_scan_finish_time = None

# -------------------------------------------------------
# Función que ejecuta scan_run.sh en segundo plano
# -------------------------------------------------------
def run_script_background():
    global scan_running, last_scan_finish_time

    scan_running = True
    with open(STATUS_FILE, "w") as f:
        f.write("RUNNING")

    try:
        subprocess.run(
            ["/bin/bash", SCRIPT_FILE],
            stdout=open(f"{BASE_PATH}/scan_stdout.log", "a"),
            stderr=open(f"{BASE_PATH}/scan_stderr.log", "a"),
            check=True
        )
    except Exception as e:
        with open(STATUS_FILE, "w") as f:
            f.write(f"ERROR: {str(e)}")
        scan_running = False
        return

    scan_running = False
    last_scan_finish_time = time.strftime("%Y-%m-%d %H:%M:%S")

    with open(STATUS_FILE, "w") as f:
        f.write(f"FINISHED at {last_scan_finish_time}")

# -------------------------------------------------------
# 1) Recibir rango de escaneo desde la web
# -------------------------------------------------------
@app.route("/run_scan", methods=["POST"])
def run_scan():
    global scan_running

    if scan_running:
        return jsonify({"message": "Ya hay un escaneo en ejecución"}), 400

    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON vacío"}), 400

    start_ip = data.get("start_ip")
    end_ip = data.get("end_ip")
    company_id = data.get("company_id")

    if not start_ip or not end_ip:
        return jsonify({"error": "Falta start_ip o end_ip"}), 400

    # Guardar parámetros en scan_params.json
    with open(PARAMS_FILE, "w") as f:
        json.dump({
            "start_ip": start_ip,
            "end_ip": end_ip,
            "company_id": company_id
        }, f)

    # Lanzar en segundo plano
    t = threading.Thread(target=run_script_background)
    t.start()

    return jsonify({"message": "Escaneo iniciado", "range": f"{start_ip} - {end_ip}"}), 200

# -------------------------------------------------------
# 2) Comprobar estado del escaneo
# -------------------------------------------------------
@app.route("/scan-status", methods=["GET"])
def scan_status():
    if scan_running:
        return jsonify({"status": "RUNNING"}), 200

    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, "r") as f:
            return jsonify({"status": f.read().strip()}), 200

    return jsonify({"status": "UNKNOWN"}), 200

# -------------------------------------------------------
# 3) Devolver el último JSON
# -------------------------------------------------------
@app.route("/get-json", methods=["GET"])
def get_json():
    if os.path.exists(JSON_FILE):
        return send_file(JSON_FILE)
    else:
        return jsonify({"error": "scan_final.json no existe"}), 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
