#!/usr/bin/env python3
import json
import sys
import time
import os
import requests

NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
# Opcional: exporta NVD_API_KEY en la Raspberry para evitar límites
NVD_API_KEY = os.getenv("NVD_API_KEY")

# Límite para no pasarnos con la longitud del texto
MAX_DESC_LEN = 200
# Máximo de CVEs por servicio
MAX_CVES_PER_SERVICE = 5
# Pausa entre peticiones para no saturar la API (en segundos)
REQUEST_DELAY = 0.6


def get_cvss_and_severity(cve_obj):
    """
    Extrae score/severity de las distintas métricas que puede tener NVD.
    """
    metrics = cve_obj.get("metrics", {})
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        if key in metrics and metrics[key]:
            m = metrics[key][0]
            cvss = m.get("cvssData", {}).get("baseScore")
            severity = m.get("cvssData", {}).get("baseSeverity") or m.get("baseSeverity")
            return cvss, severity
    return None, None


def get_english_description(cve_obj):
    descs = cve_obj.get("descriptions", [])
    for d in descs:
        if d.get("lang") == "en":
            return d.get("value", "")
    # Si no hay en inglés, devolvemos el primero
    return descs[0].get("value", "") if descs else ""


def query_nvd(service, version):
    """
    Consulta la NVD para un servicio + versión concretos.
    Devuelve una lista de vulnerabilidades en formato simplificado.
    """
    # Construimos un query razonable: "apache 2.4.41", "openssh 8.4"...
    query = f"{service} {version}".strip()
    params = {
        "keywordSearch": query,
        "resultsPerPage": MAX_CVES_PER_SERVICE,
    }
    headers = {}
    if NVD_API_KEY:
        headers["apiKey"] = NVD_API_KEY

    print(f"[NVD] Buscando CVEs para: '{query}'")
    try:
        resp = requests.get(NVD_API_URL, params=params, headers=headers, timeout=20)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"[NVD] Error consultando NVD para '{query}': {e}")
        return []

    vulns = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id")

        cvss, severity = get_cvss_and_severity(cve)
        desc = get_english_description(cve)
        if len(desc) > MAX_DESC_LEN:
            desc = desc[:MAX_DESC_LEN] + "..."

        vulns.append({
            "cve": cve_id,
            "cvss": cvss,
            "severity": severity,
            "description": desc,
            "published": cve.get("published"),
            "updated": cve.get("lastModified"),
        })

    return vulns


def main():
    if len(sys.argv) != 3:
        print("Uso: map_vulns.py scan_intermediate.json scan_final.json")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    with open(input_file, "r") as f:
        data = json.load(f)

    hosts = data.get("hosts", [])

    # Cache para no repetir llamadas a NVD por el mismo servicio+versión
    cache = {}

    for host in hosts:
        ports = host.get("ports", [])
        for port in ports:
            service = (port.get("service") or "").strip()
            version = (port.get("version") or "").strip()

            # Inicializamos siempre la clave "vulns"
            port_vulns = []

            # Si no hay servicio o versión, no buscamos nada
            if not service:
                port["vulns"] = port_vulns
                continue

            # Clave de cache → service + primera "palabra" de la versión
            # (para no hacer consultas ultra específicas tipo "Ubuntu 20.04")
            short_version = version.split()[0] if version else ""
            cache_key = (service.lower(), short_version.lower())

            if cache_key in cache:
                vulns_for_service = cache[cache_key]
            else:
                vulns_for_service = query_nvd(service, short_version)
                cache[cache_key] = vulns_for_service
                time.sleep(REQUEST_DELAY)  # Respetar rate-limit

            port_vulns.extend(vulns_for_service)
            port["vulns"] = port_vulns

    # Guardar resultado final
    with open(output_file, "w") as f:
        json.dump({"hosts": hosts}, f, indent=2)

    print(f"[OK] Vulnerabilidades mapeadas desde NVD. Guardado: {output_file}")


if __name__ == "__main__":
    main()
