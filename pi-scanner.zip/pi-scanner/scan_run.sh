#!/bin/bash
set -e

# Activar entorno Python
source /opt/pi-scanner/venv/bin/activate

BASE=/opt/pi-scanner
RESULTS="$BASE/results"
PARAMS="$BASE/scan_params.json"

SERVER_URL="https://10.11.0.154/api/scan_results"   # ← AJUSTA IP SI HACE FALTA
API_KEY="S2V5TXVzdEJlMTZCeXRlT1IyNEJ5dGVPUjMyQnlUNCE"  # ← TU API KEY REAL

mkdir -p "$RESULTS"
cd "$RESULTS"

# Limpiar resultados antiguos (dejar últimos 5)
ls -t | tail -n +6 | xargs rm -rf 2>/dev/null || true

TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUTDIR="$RESULTS/$TIMESTAMP"
mkdir -p "$OUTDIR"

echo "[+] Carpeta de salida: $OUTDIR"

# ---------------------------------------------
# Leer parámetros desde scan_params.json (si existe)
# ---------------------------------------------
START_IP=""
END_IP=""
COMPANY_ID="1"

if [ -f "$PARAMS" ]; then
    echo "[+] Leyendo parámetros desde $PARAMS"
    # OJO: usamos '|| echo ""' para que, aunque jq falle, no reviente el script (set -e)
    START_IP=$(jq -r '.start_ip // empty' "$PARAMS" 2>/dev/null || echo "")
    END_IP=$(jq -r '.end_ip // empty' "$PARAMS" 2>/dev/null || echo "")
    COMPANY_ID=$(jq -r '.company_id // "1"' "$PARAMS" 2>/dev/null || echo "1")
else
    echo "[!] $PARAMS no existe. Usando rango por defecto y company_id=1."
fi

# ---------------------------------------------
# Construir rango de escaneo
# ---------------------------------------------
if [ -n "$START_IP" ] && [ -n "$END_IP" ]; then
    PREFIX=$(echo "$START_IP" | cut -d'.' -f1-3)
    START=$(echo "$START_IP" | cut -d'.' -f4)
    END=$(echo "$END_IP" | cut -d'.' -f4)
    RANGE="$PREFIX.$START-$END"
    echo "[+] Usando rango recibido: $RANGE"
else
    IP_INFO=$(ip -4 -o addr show scope global | awk '{print $4; exit}')
    NETWORK_BASE=$(echo "$IP_INFO" | cut -d'.' -f1-3)
    RANGE="$NETWORK_BASE.1-63"
    echo "[+] WARNING: No se han recibido IPs válidas. Usando rango por defecto: $RANGE"
fi

echo "[+] Escaneando rango $RANGE..."
nmap --top-ports 50 -sS -sV "$RANGE" -oX "$OUTDIR/scan.xml"


# ---------------------------------------------
# Combinar XML en merged_nmap.xml
# ---------------------------------------------
python3 /opt/pi-scanner/merge_nmap_xml.py

# Convertir a JSON intermedio
python3 /opt/pi-scanner/parse_to_json.py \
    "$OUTDIR/merged_nmap.xml" "$OUTDIR/scan_intermediate.json"

# Mapear vulnerabilidades
python3 /opt/pi-scanner/map_vulns.py \
    "$OUTDIR/scan_intermediate.json" "$OUTDIR/scan_final.json"

# Copiar resultado a la raíz para que lo sirva /get-json
cp "$OUTDIR/scan_final.json" "$BASE/scan_final.json"

echo "[✔] Escaneo completado. JSON final: $OUTDIR/scan_final.json"

# ---------------------------------------------
# Enviar JSON al servidor web
# ---------------------------------------------
echo "[+] Enviando resultados al servidor: $SERVER_URL?company_id=$COMPANY_ID"

UPLOAD_RESP="$OUTDIR/upload_response.json"

curl -k -f -sS -X POST "$SERVER_URL?company_id=$COMPANY_ID" \
    -H "Content-Type: application/json" \
    -H "X-API-KEY: $API_KEY" \
    --data "@$BASE/scan_final.json" \
    -o "$UPLOAD_RESP" || CURL_CODE=$?

if [ -z "$CURL_CODE" ]; then
    echo "[+] Resultados enviados correctamente. Respuesta:"
    cat "$UPLOAD_RESP"
else
    echo "[!] ERROR al enviar resultados (curl code=$CURL_CODE). Respuesta (si la hay):"
    cat "$UPLOAD_RESP" 2>/dev/null || echo "(sin respuesta)"
fi
